# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pdarena_test_lib']

package_data = \
{'': ['*']}

install_requires = \
['rich>=13.0.0,<14.0.0']

setup_kwargs = {
    'name': 'pdarena-test-lib',
    'version': '0.1.0',
    'description': '',
    'long_description': 'Install this repository as a package and use it like so:\n\n```python\nfrom pdarena_test_lib import Validator\n\n# takes two arguments: n_matchups and n_rounds\nvalidator = Validator(10, 10)\n\ndef should_defect(opponent, history):\n    # YOUR CODE GOES HERE\n    pass\n\nvalidator.validate(should_defect)\n```\n\nThis will print a message indicating whether your bot is valid. If your bot is valid, the message will contain its overall score against each testcase. If your bot is invalid, the message will contain the reason why.\n\nYou can also define your own testcases:\n\n```python\nfrom pdarena_test_lib import Validator\n\ntestcases = [\n    # YOUR TESTCASES GO HERE\n]\n\nvalidator = Validator(10, 10, testcases)\n```\n\n# installation\n\n## ...with pip\n\nRun the following:\n\n`pip install git+https://github.com/cosmicoptima/pdarena-test-lib`\n\n## ...with poetry\n\nAdd the following to `pyproject.toml` under `tool.poetry.dependencies`:\n\n```toml\npdarena-test-lib = { git = "https://github.com/cosmicoptima/pdarena-test-lib" }\n```\n',
    'author': 'celeste',
    'author_email': 'parafactual@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
